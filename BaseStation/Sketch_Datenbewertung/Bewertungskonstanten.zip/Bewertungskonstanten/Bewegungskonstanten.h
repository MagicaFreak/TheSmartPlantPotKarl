//ideale Bedingungen fuer Temperatur zwischen 16 und 30 Grad Celsius
#define MAX_TEMP 30
#define MIN_TEMP 16
//ideale Bedingungen zwischen 40% und 60% relative Luftfeuchtigkeit
#define MAX_AIR_HUM 60
#define MIN_AIR_HUM 40
//ideale Bedingungen zwischen 60% und 70% relative Bodenfeuchtigkeit
#define MAX_SOI_HUM 70
#define MIN_SOI_HUM 60

//ideale Lichtintensitaet Bedingungen muessen zwischen 100-600umol/m2s oder PPFD sein
//Wie das zu gross fuer die Lichtwiderstaende ist, wir messen nur, ob die Licht uniform fuer alle Photozellen ausstrahlt
//Wie der Unterschied in Lux logarithmisch ist, bei der maximal angemessene Lux-Wert (100lx), ein Haelfte von Intensitaet waere dann
//ungefaehr 63,096lx
#define N_LIGHT_SENSORS 8
#define MIN_LIGHT 10
#define MAX_LIGHT 100
#define MAX_LIGHT_DIFF 37